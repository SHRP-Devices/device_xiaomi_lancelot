#!/sbin/sh
mount -o rw /system_root
rm -rf /sdcard/imeibackup /sdcard/imeibackup.zip
mkdir -p /sdcard/imeibackup 
for part in nvcfg nvdata persist protect1 protect2; do dd if=/dev/block/platform/bootdevice/by-name/$part of=/sdcard/imeibackup/${part}.img; done
for part in seccfg nvram; do dd if=/dev/block/platform/bootdevice/by-name/$part of=/sdcard/imeibackup/${part}.bin; done
zip -r /sdcard/imeibackup.zip /sdcard/imeibackup

